#include "numeric.h"

Numeric::Numeric(std::string& line){
	if(!checkNum(line)) return;
	intPart = "";
	intPart += line.substr(line[0], (line.find(comma)-1));
	fractPart = "";
	fractPart += line.substr((line.find(comma)+1), (line.length()-line.find(comma)-1));
	int countComma = 0;
	interpret = 0;
	int ind =0;
	if (line[0] == '-') {sign = '-'; ind = 1;}
	for(int i = ind; i < line.length(); ++i)
	{
		if (line[i] != comma){
			if(countComma == 0){
				interpret += (line[i] - '0') * pow(10,i-ind);
			}else if (countComma == 1){
				interpret += (line[i] - '0') / pow(10,i-ind);
			}
		}else ++countComma;
		
	}
}

bool Numeric::checkNum(const std::string &line){
	int countComma = 0;
	int ind = 0;
	if(line[0] == '-') {
		sign = '-';
		ind = 1;
	}
	for(int i = ind; i < line.length(); ++i){
		if(line[i] >= '0' && line[i] <= '9'){

		}else if(line[i] == comma){
			if (countComma < 1 ) ++countComma;
			else return false;
		} else return false;
	}
	return true;
}

bool Numeric::setComma(const char a){
	if(a != '.' && a !=',') return false;
	comma = a;
	return true;
}