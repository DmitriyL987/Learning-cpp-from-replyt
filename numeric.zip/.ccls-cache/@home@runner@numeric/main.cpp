#include <iostream>
#include <cmath>
#include <regex>

#include "numeric.h"

int main() {
	std::string str = "1589222155662.156894646666464";
	Numeric num(str);
	std::cout << num.getNum() << std::endl;
} 