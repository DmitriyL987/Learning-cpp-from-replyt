#include <iostream>
#include <string>
#include <cmath>


class Numeric
{
	std::string intPart = "";
	std::string fractPart = "";
	long double interpret = 0;
	char comma = '.';
	char sign = '+';
public:
	Numeric(std::string& line);
	bool setComma(const char a);
	bool checkNum(const std::string& line);
	long double& to_float(const std::string&);
	std::string& to_string(long double&);
	void setIntPart(const std::string&);
	void setFractPart(const std::string&);
	long double getNum(){return interpret;}
};